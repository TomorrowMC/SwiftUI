import UIKit

import CoreML

let config=MLModelConfiguration()
let model=try!SleepCalculator(configuration: config)
let result = try! model.prediction(wake: 32400, estimatedSleep: 8.5, coffee: 1.0)
print(result.featureNames)
